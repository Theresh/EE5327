# Optimization_gvv
Optimization presentations and python scripts
